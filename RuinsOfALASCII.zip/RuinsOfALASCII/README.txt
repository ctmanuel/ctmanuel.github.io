                 _____       _                    __                 
                |  __ \     (_)                  / _|                
                | |__) |   _ _ _ __  ___    ___ | |_                 
                |  _  / | | | | '_ \/ __|  / _ \|  _|                
                | | \ \ |_| | | | | \__ \ | (_) | |                  
                |_|  \_\__,_|_|_| |_|___/  \___/|_|                  
                   _                _____  _____ _____ _____         
             /\   | |        /\    / ____|/ ____|_   _|_   _|        
            /  \  | |       /  \  | (___ | |      | |   | |          
           / /\ \ | |      / /\ \  \___ \| |      | |   | |          
          / ____ \| |____ / ____ \ ____) | |____ _| |_ _| |_         
         /_/    \_\______/_/    \_\_____/ \_____|_____|_____|             

                             Evan Polekoff
                            Christian Manuel

/*============================*\
||         How to Run         ||
\*============================*/

Windows: You will need cygwin installed to play this game. It was built for linux and uses some files incompatible on Windows without using cygwin.
If you have cygwin, double click on RunGame.bat. That's the easiest way.

Linux: ./roa-linux will do it.

/*============================*\
||        How To Play         ||
\*============================*/

Arrow Keys - Move
Space - Shoot
Run through the maze and shoot enemies for points. Grab treasure chests for extra points. Grab health packs for extra health. Find the portal (a blue circle) to go to the next floor.

The game should be self explanatory and the title screen will give more controls. If you want to read every detail about the game, I've rambled on about it below:

---------------
The map created will be randomly generated. The complexity of the map is variable, which allows us to make the maps more difficult as the player progresses.

There are multiple enemy types that can be found in the dungeon. The first is a small yellow enemy designed to look like a treasure chest to trick the player. If the player steps on the same x or y axis as this enemy, it will chase him in a straight line. The second type is a red enemy that sits still and shoots bullets randomly in different directions. The bullets do a lot of damage and carelessly walking into it does even more. The third type is a big green enemy that moves randomly and unpredictably.

Upon stepping on a portal (a dark-blue circle), the player will be transported to the next "level", which has a more complex map. As the game goes on, more and more enemies will spawn and the end portal will be harder to find.

The views show the player's health, score and what level he is currently on. Health can be lost by hitting enemies and increased by picking up Med-Packs (red flashing squares) that appear randomly. The score can be increased by shooting enemies and finding treasure (yellow squares) that also appear randomly. The level is increased by going through portals, but the player cannot go back to earlier levels once moving on.

When a player loses all of his health, the game will end and return to the title screen. The title screen shows the controls for how to play and quit out of game.